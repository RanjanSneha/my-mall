package com.example.mymall;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;

import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageButton;
import android.widget.ProgressBar;
import android.text.SpannableString;
import android.text.style.UnderlineSpan;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;

public class SigninFragment extends Fragment {
    public SigninFragment() {
        // Required empty public constructor
    }

    private TextView donthaveaccount;
    private FrameLayout parentframelayout;
    private EditText signinemail;
    private EditText signinpassword;
    private TextView closebtn;
    private Button signinbtn;
    private FirebaseAuth firebaseAuth;
    private String EmailPattern="[a-zA-Z0-9._-]+@[a-z]+.[a-z]+";
    private String PasswordPattern="^(?=.*[0-9])(?=.*[a-z])(?=.*[A-Z])(?=.*[@#$%^&+=])(?=\\S+$).{4,}$";
    private ProgressBar progressBar;

    SharedPreferences sharedPreferences;
    private TextView forgotpassword;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_signin, container, false);
        donthaveaccount = view.findViewById(R.id.signup_link);
        parentframelayout=getActivity().findViewById(R.id.register_frame_layout);
        signinemail=view.findViewById(R.id.input_email);
        signinpassword=view.findViewById(R.id.input_password);
        progressBar=view.findViewById(R.id.progressbar);
        closebtn=view.findViewById(R.id.skip_button);
        signinbtn=view.findViewById(R.id.signin_button);
        forgotpassword=view.findViewById(R.id.forget_password_link);

        SpannableString content = new SpannableString("SKIP");
        content.setSpan(new UnderlineSpan(), 0, content.length(), 0);
        closebtn.setText(content);


        firebaseAuth=FirebaseAuth.getInstance();

        sharedPreferences=getActivity().getSharedPreferences("login", Context.MODE_PRIVATE);
        return view;
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        donthaveaccount.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                setFragment(new SignupFragment());
            }
        });

        closebtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mainintent();
            }
        });

        signinbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                checkinputs();


            }
        });

        forgotpassword.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                setFragment(new Forgot_pwd());
            }
        });
    }



    private void setFragment(Fragment fragment) {
        FragmentTransaction fragmentTransaction=getActivity().getSupportFragmentManager().beginTransaction();
        fragmentTransaction.setCustomAnimations(R.anim.slide_from_right,R.anim.slideout_from_left);
        fragmentTransaction.replace(parentframelayout.getId(),fragment);
        fragmentTransaction.commit();
    }

    private void checkinputs() {
        if(TextUtils.isEmpty(signinemail.getText().toString())){
            signinemail.setError("Please Enter your Email");
        }
        else if(TextUtils.isEmpty(signinpassword.getText().toString())){
            signinpassword.setError("Please Enter your Password");
        }
        else {
            checkemailandpassword();
        }
    }

    private void checkemailandpassword() {
        if (signinemail.getText().toString().matches(EmailPattern)){
            if (signinpassword.getText().toString().matches(PasswordPattern)){
                progressBar.setVisibility(View.VISIBLE);
                signinbtn.setEnabled(false);
                signinbtn.setTextColor(Color.argb(50,255,255,255));

                firebaseAuth.signInWithEmailAndPassword(signinemail.getText().toString(),signinpassword.getText().toString())
                        .addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                            @Override
                            public void onComplete(@NonNull Task<AuthResult> task) {
                                if (task.isSuccessful()){
                                    mainintent();
                                }
                                else {
                                    progressBar.setVisibility(View.INVISIBLE);
                                    signinbtn.setEnabled(true);
                                    signinbtn.setTextColor(Color.rgb(255,255,255));
                                    String error=task.getException().getMessage();
                                    Toast.makeText(getActivity(),error, Toast.LENGTH_SHORT).show();
                                }
                            }
                        });
            }
            else {
                signinpassword.setError("Password is Incorrect");
            }
        }
        else {
            signinpassword.setError("Invalid Email");
        }
    }

    private void mainintent(){
        Intent intent=new Intent(getActivity(),MainActivity2.class);
        startActivity(intent);
        getActivity().finish();

    }

}