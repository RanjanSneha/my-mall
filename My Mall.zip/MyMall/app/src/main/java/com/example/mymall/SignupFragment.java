package com.example.mymall;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;

import android.text.Editable;
import android.text.SpannableString;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.text.style.UnderlineSpan;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.FirebaseFirestore;

import java.util.HashMap;
import java.util.Map;
import java.util.regex.Pattern;

public class SignupFragment extends Fragment {

    public SignupFragment() {
        // Required empty public constructor
    }

    private TextView Alreadyhaveaccount;
    private FrameLayout parentframelayout;
    private EditText email;
    private EditText fullname;
    private EditText password;
    private EditText confirmpassword;
    private TextView closebtn2;
    private Button signupbtn;
    private ProgressBar progressbar;
    private FirebaseAuth firebaseAuth;
    private String emailpattern="[a-zA-Z0-9._-]+@[a-z]+.[a-z]+";
    private String  passwordpattern = "^(?=.*[0-9])(?=.*[a-z])(?=.*[A-Z])(?=.*[@#$%^&+=])(?=\\S+$).{4,}$";

    private FirebaseFirestore firebaseFirestore;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view= inflater.inflate(R.layout.fragment_signup, container, false);
        Alreadyhaveaccount=view.findViewById(R.id.signin_link);
        parentframelayout=getActivity().findViewById(R.id.register_frame_layout);
        email=view.findViewById(R.id.input_email2);
        fullname=view.findViewById(R.id.input_name);
        password=view.findViewById(R.id.input_password2);
        confirmpassword=view. findViewById(R.id.input_confirm_password);
        closebtn2=view.findViewById(R.id.skip_button2);
        signupbtn=view.findViewById(R.id.signup_button);
        progressbar=view.findViewById(R.id.progressBar2);

        SpannableString content = new SpannableString("SKIP");
        content.setSpan(new UnderlineSpan(), 0, content.length(), 0);
        closebtn2.setText(content);


        firebaseAuth=FirebaseAuth.getInstance();
        firebaseFirestore=FirebaseFirestore.getInstance();

            return view;
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        Alreadyhaveaccount.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                setFragment(new SigninFragment());
            }
        });

        closebtn2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mainIntent();
            }
        });

        signupbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                checkInputs();
            }
        });

    }



    private void setFragment(Fragment fragment) {
        FragmentTransaction fragmentTransaction=getActivity().getSupportFragmentManager().beginTransaction();
        fragmentTransaction.setCustomAnimations(R.anim.slide_from_left,R.anim.slideout_from_right);
        fragmentTransaction.replace(parentframelayout.getId(),fragment);
        fragmentTransaction.commit();

    }

    private void checkInputs() {
        if(TextUtils.isEmpty(email.getText().toString())){
            email.setError("Please Enter your Email");
        }
        else if(TextUtils.isEmpty(fullname.getText().toString())){
            fullname.setError("Please Enter your Full Name");
        }
        else if(TextUtils.isEmpty(password.getText().toString())){
            password.setError("Please Enter your Password");
        }
        else if(TextUtils.isEmpty(confirmpassword.getText().toString())){
            confirmpassword.setError("Please Enter your Password again");
        }
        else {
            checkEmailAndPassword();
        }
    }

    private void checkEmailAndPassword(){
        if(email.getText().toString().matches(emailpattern)) {
            if (password.getText().toString().matches(passwordpattern)) {
                if (password.getText().toString().equals(confirmpassword.getText().toString())) {
                    progressbar.setVisibility(View.VISIBLE);
                    signupbtn.setEnabled(false);
                    signupbtn.setTextColor(Color.argb(50, 255, 255, 255));

                    firebaseAuth.createUserWithEmailAndPassword(email.getText().toString(), password.getText().toString())
                            .addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                                @Override
                                public void onComplete(@NonNull Task<AuthResult> task) {
                                    if (task.isSuccessful()) {

                                        Map<Object,String>userdata=new HashMap<>();
                                        userdata.put("fullname",fullname.getText().toString());

                                        firebaseFirestore.collection("USERS").add(userdata)
                                                .addOnCompleteListener(new OnCompleteListener<DocumentReference>() {
                                                    @Override
                                                    public void onComplete(@NonNull Task<DocumentReference> task) {
                                                        if(task.isSuccessful()){
                                                           mainIntent();
                                                        }else {
                                                            progressbar.setVisibility(View.INVISIBLE);
                                                            signupbtn.setEnabled(true);
                                                            signupbtn.setTextColor(Color.rgb(255, 255, 255));
                                                            String error = task.getException().getMessage();
                                                            Toast.makeText(getActivity(), error, Toast.LENGTH_SHORT).show();
                                                        }
                                                    }
                                                });


                                    } else {
                                        progressbar.setVisibility(View.INVISIBLE);
                                        signupbtn.setEnabled(true);
                                        signupbtn.setTextColor(Color.rgb(255, 255, 255));
                                        String error = task.getException().getMessage();
                                        Toast.makeText(getActivity(), error, Toast.LENGTH_SHORT).show();
                                    }
                                }
                            });
                } else {
                    confirmpassword.setError("Password doesn't match");
                }
            }
            else{
                password.setError("Password must have upper case[A-Z],lower case[a-z],numbers[0-9],special char[@,/]");
            }
        }
        else {
            email.setError("Invalid Email");
        }

    }

    private void mainIntent(){
        Intent intent = new Intent(getActivity(), MainActivity2.class);
        startActivity(intent);
        getActivity().finish();
    }
}